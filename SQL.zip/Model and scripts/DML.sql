INSERT INTO Clients (Client_Name, PHONE_NUMBER, PASSWORD)
VALUES	("Alex", "+380668761542", "*******"),
		("Maria", "+380988765744", "*******"),
		("Anton", "+380988786544", "*******"),
		("Serhii", "+380503876533", "*******"),
		("Hanna", "+380668764522", "*******"),
		("Oleg", "+3805083323144", "*******"),
		("Lesya", "+380662223344", "*******");

INSERT INTO Ticket_Status (Ticket_Status_Name)
VALUES	("Waiting"),
		("In Progress"),
		("Resolved");

INSERT INTO Operator_Type (Operator_Type_Name)
VALUES	("Basic"),
		("Technical");
        
INSERT INTO Ticket_Type (Ticket_Type_Name)
VALUES	("General Request/Question"),
		("Payment Issue"),
		("Delivery Delay"),
		("Product Quality"),
		("Some of the services not available");
        
INSERT INTO Tickets (Topic, Description, Client_ID, Ticket_Type_ID, Ticket_Status_ID, Resolution)
VALUES	("My payment is not completed", "I tried to pay for service, but after 3D secure I receive error page", 1, 2, 1, NULL),
		("I haven't received my shoes yet!!!", "It've been 30 days, but my shoes haven't come yet!", 2, 3, 3, "Order received"),
		("Filter doesn't work", "Hi Support, I tried to filter goods by both colour and style, but the filters are not applied simultaniously. Please advice how to solve it", 6, 5, 2, NULL),
		("Received Book is in terrible condition!", "The book The Great Gatsby came dirty and with missed pages. It was in use for sure!!!", 7, 4, 3, "Money were returned back to customer"),
		("Payment issue", "After I completed my payment I haven't received any confirmation from your site.", 5, 2, 2, NULL),
		("I can't change my delivery address", "I moved to another city and need to change my delivery adress", 1, 1, 3, "`The adress was changed by operator");
       
INSERT INTO Operators (Operator_Name, Operator_Type_ID, Is_Available)
VALUES	("Sviatislav", 1, 0),
		("Iryna", 2, 0),
		("Volodymyr", 1, 1);       

INSERT INTO Tickets_Assignments (Ticket_ID, OPERATOR_ID, Is_Active, Resolution_Comment)
VALUES	(1, 1, 1, NULL),
		(2, 3, 0, "Resolved"),
        (3, 3, 0, "Technocal Issue. Moved to TechSupport"),
        (3, 2, 1, "Seems like cash issue. Working on it"),
        (4, 1, 0, "Resolved"),
        (5, 3, 0, "Seems like technical Issue. Moved to TechSupport"),
        (5, 2, 0, "Third-party bank issue. Moving back to Support"),
        (5, 1, 1, "Waiting for customer to contact bank."),
        (6, 1, 0, "Changed address for customer.");