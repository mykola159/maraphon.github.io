DROP DATABASE IF EXISTS Support;
CREATE DATABASE Support;
USE Support;

CREATE TABLE Clients
(
	Client_ID INTEGER NOT NULL AUTO_INCREMENT,
    Client_Name VARCHAR(400) NOT NULL,
    PHONE_NUMBER VARCHAR(20) NOT NULL,
    PASSWORD VARCHAR(10) NOT NULL,
    CONSTRAINT PK_Clients PRIMARY KEY (Client_ID)
);

CREATE TABLE Tickets
(
	Ticket_ID INTEGER NOT NULL AUTO_INCREMENT,
    Topic VARCHAR(200) NOT NULL,
    Description VARCHAR(4000) NULL,
    Client_ID INTEGER NOT NULL,
    Ticket_Type_ID INTEGER NOT NULL,
    Ticket_Status_ID INTEGER NOT NULL DEFAULT 1,
    Resolution VARCHAR(1000) NULL,
    CONSTRAINT PK_Tickets PRIMARY KEY (Ticket_ID)
);

CREATE TABLE Ticket_Status
(
	Ticket_Status_ID INTEGER NOT NULL AUTO_INCREMENT,
    Ticket_Status_Name VARCHAR(20) NOT NULL,
    CONSTRAINT PK_Ticket_Status PRIMARY KEY (Ticket_Status_ID)
);

CREATE TABLE Operators
(
	Operator_ID INTEGER AUTO_INCREMENT,
    Operator_Name VARCHAR(300) DEFAULT 1,
    Operator_Type_ID INTEGER,
    Is_Available BOOLEAN,
    CONSTRAINT PK_Operators PRIMARY KEY (Operator_ID)
);

CREATE TABLE Operator_Type
(
	Operator_Type_ID INTEGER NOT NULL AUTO_INCREMENT,
    Operator_Type_Name VARCHAR(15) NOT NULL,
    CONSTRAINT PK_Operator_Type PRIMARY KEY (Operator_Type_ID)
);

CREATE TABLE Ticket_Type
(
	Ticket_Type_ID INTEGER NOT NULL AUTO_INCREMENT,
    Ticket_Type_Name VARCHAR(100) NOT NULL,
    CONSTRAINT PK_Ticket_Type PRIMARY KEY (Ticket_Type_ID)
);

CREATE TABLE Tickets_Assignments
(
	Ticket_ID INTEGER NOT NULL,
    OPERATOR_ID INTEGER NULL,
    Is_Active BOOLEAN NOT NULL DEFAULT 0,
    Resolution_Comment VARCHAR(2000) NULL
);

ALTER TABLE Tickets_Assignments ADD CONSTRAINT PK_Tickets_Assignments PRIMARY KEY (Ticket_ID, OPERATOR_ID);


ALTER TABLE Tickets ADD CONSTRAINT FK_Ticket_Client_ID FOREIGN KEY (Client_ID) REFERENCES Clients(Client_ID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Ticket_Ticket_Status_ID FOREIGN KEY (Ticket_Status_ID) REFERENCES Ticket_Status(Ticket_Status_ID);
ALTER TABLE Tickets_Assignments ADD CONSTRAINT FK_Tickets_Assignments_Ticket_ID FOREIGN KEY (Ticket_ID) REFERENCES Tickets(Ticket_ID);
ALTER TABLE Tickets_Assignments ADD CONSTRAINT FK_Tickets_Assignments_Operator_ID FOREIGN KEY (Operator_ID) REFERENCES Operators(Operator_ID);
ALTER TABLE Operators ADD CONSTRAINT FK_Operators_Operator_Type_ID FOREIGN KEY (Operator_Type_ID) REFERENCES Operator_Type(Operator_Type_ID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Tickets_Ticket_Type_ID FOREIGN KEY (Ticket_Type_ID) REFERENCES Ticket_Type(Ticket_Type_ID);