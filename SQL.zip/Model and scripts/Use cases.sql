/*	1.1	*/
INSERT INTO Tickets (Topic, Description, Client_ID, Ticket_Type_ID, Ticket_Status_ID, Resolution)
VALUES	("I add item into busket, but it's still empty", "I'm adding item to the busket, but when I enter it no products found", 2, 5, 1, NULL);

SELECT Ticket_ID, Topic, Description, Client_ID, Ticket_Type_ID, Ticket_Status_ID, Resolution
FROM Tickets
ORDER BY Ticket_ID DESC
LIMIT 1;

/*	2.2	*/
SELECT  Operator_Name, Operator_Type_Name, CASE Is_Available WHEN 0 THEN "Not available" WHEN 1 THEN "Available" END AS Availability
FROM Operators O
JOIN Operator_Type OP
	ON O.Operator_Type_ID = OP.Operator_Type_ID;
    
/*	2.2	*/
SELECT Ticket_Status_Name
FROM Tickets T
JOIN Ticket_Status TS
	ON T.Ticket_Status_ID = TS.Ticket_Status_ID
WHERE Ticket_ID = 3;


/*	3.2	*/
SELECT C.Client_Name, C.PHONE_NUMBER, T.Topic, T.Description, TS.Ticket_Status_Name, TT.Ticket_Type_Name
FROM Clients C 
JOIN Tickets T
	ON C.Client_ID = T.Client_ID
JOIN Ticket_Status TS
	ON T.Ticket_Status_ID = TS.Ticket_Status_ID
JOIN Ticket_Type TT
	ON TT.Ticket_Type_ID = T.Ticket_Type_ID
WHERE C.PHONE_NUMBER = "+380668761542"
GROUP BY C.Client_Name, C.PHONE_NUMBER, T.Topic, T.Description, TS.Ticket_Status_Name, TT.Ticket_Type_Name
ORDER BY C.Client_Name, C.PHONE_NUMBER, T.Topic, T.Description, TS.Ticket_Status_Name, TT.Ticket_Type_Name;